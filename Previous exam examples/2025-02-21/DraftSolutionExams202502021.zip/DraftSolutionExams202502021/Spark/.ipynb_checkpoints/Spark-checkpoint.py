#!/usr/bin/env python
import sys
from pyspark import SparkContext

def main():
    #if len(sys.argv) < 6:
    #    print("Usage: <TVSeries.txt> <Episodes.txt> <UserWatched.txt> <OutputFolderPart1> <OutputFolderPart2>")
    #    sys.exit(-1)

    # File paths from arguments
    #tvseries_path =     "TVSeries.txt" #    sys.argv[1]
    #episodes_path =     "Episodes.txt" #    sys.argv[2]
    #userwatched_path =  "UserWatched.txt" # sys.argv[3]
    output_part1 =      "./output1" #       sys.argv[4]
    output_part2 =      "./output2" #       sys.argv[5]

    sc = SparkContext.getOrCreate()
    sc.setLogLevel("ERROR")

    # Compute the maximum number of seasons per TV series (shared computation for both parts)
    # Load Episodes.txt: each line is TVSID,SeasonNumber,EpisodeNumber,Title
    episodes_rdd = sc.textFile("Episodes.txt").map(lambda line: line.split(','))
    # Map to key=TVSID, value=SeasonNumber (converted to integer)
    episodes_seasons_rdd = episodes_rdd.map(lambda x: (x[0], int(x[1])))
    # Reduce by key to find the maximum SeasonNumber for each TVSID
    # Result: key=TVSID, value=max_seasons
    max_seasons_rdd = episodes_seasons_rdd.reduceByKey(lambda a, b: max(a, b))

    # Part 1: Number of long TV series for each TV series genre
    # A long TV series has more than 10 seasons
    # Filter TV series with max_seasons > 10
    # Result: key=TVSID, value=max_seasons (only for long series)
    long_series_rdd = max_seasons_rdd.filter(lambda x: x[1] > 10)

    # Load TVSeries.txt: each line is TVSID,Title,TVGenre
    tvseries_rdd = sc.textFile("TVSeries.txt").map(lambda line: line.split(','))
    # Map to key=TVSID, value=TVGenre
    tvseries_genre_rdd = tvseries_rdd.map(lambda x: (x[0], x[2]))

    # Join long_series_rdd with tvseries_genre_rdd to associate long series with their genres
    # long_series_rdd: key=TVSID, value=max_seasons
    # tvseries_genre_rdd: key=TVSID, value=TVGenre
    # Join result: key=TVSID, value=(max_seasons, TVGenre)
    # Map to key=TVGenre, value=1 for counting
    long_series_genre_rdd = long_series_rdd.join(tvseries_genre_rdd)\
                                           .map(lambda x: (x[1][1], 1))

    # Count the number of long series per genre
    # Reduce by key to sum the 1s for each TVGenre
    # Result: key=TVGenre, value=count_of_long_series
    genre_count_rdd = long_series_genre_rdd.reduceByKey(lambda a, b: a + b)

    # Format output as "TVGenre,count"
    # Only genres with at least one long series appear (count >= 1), satisfying the requirement
    output_part1_rdd = genre_count_rdd.map(lambda x: f"{x[0]},{x[1]}")

    # Save to the first output folder
    output_part1_rdd.saveAsTextFile(output_part1)

    ##############################################################
    # Part 2: The longest TV series each user has started watching
    # Load UserWatched.txt: each line is Username,StartTimestamp,TVSID,SeasonNumber,EpisodeNumber
    userwatched_rdd = sc.textFile("UserWatched.txt").map(lambda line: line.split(','))

    # Filter for episodes where SeasonNumber=1 and EpisodeNumber=1 (user started watching)
    # Convert SeasonNumber and EpisodeNumber to integers for comparison
    started_watching_rdd = userwatched_rdd.filter(lambda x: int(x[3]) == 1 and int(x[4]) == 1)

    # Map to key=Username, value=TVSID and remove duplicates
    # Distinct ensures each (Username, TVSID) pair is unique, even if watched multiple times
    # Result: key=Username, value=TVSID
    started_watching_rdd = started_watching_rdd.map(lambda x: (x[0], x[2])).distinct()

    # Prepare to join with max_seasons_rdd by swapping keys
    # Map to key=TVSID, value=Username
    user_tvs_rdd = started_watching_rdd.map(lambda x: (x[1], x[0]))

    # Join with max_seasons_rdd to get the number of seasons for each started series
    # max_seasons_rdd: key=TVSID, value=max_seasons
    # Join result: key=TVSID, value=(Username, max_seasons)
    # Map to key=Username, value=(TVSID, max_seasons)
    user_series_rdd = user_tvs_rdd.join(max_seasons_rdd) \
                                  .map(lambda x: (x[1][0], (x[0], x[1][1])))

    # Find the maximum number of seasons per user
    # Map to key=Username, value=max_seasons
    # Reduce by key to get the maximum seasons for each user
    # Result: key=Username, value=max_max_seasons
    max_user_seasons_rdd = user_series_rdd.map(lambda x: (x[0], x[1][1])) \
                                          .reduceByKey(lambda a, b: max(a, b))

    # Join to find all series matching the maximum seasons per user
    # user_series_rdd: key=Username, value=(TVSID, max_seasons)
    # max_user_seasons_rdd: key=Username, value=max_max_seasons
    # Join result: key=Username, value=((TVSID, max_seasons), max_max_seasons)
    combined_rdd = user_series_rdd.join(max_user_seasons_rdd)

    # Filter to keep only series where the number of seasons equals the user's maximum
    # Filter condition: max_seasons == max_max_seasons
    # Map to key=Username, value=TVSID
    result_rdd = combined_rdd.filter(lambda x: x[1][0][1] == x[1][1]) \
                             .map(lambda x: (x[0], x[1][0][0]))

    # Format output as "Username,TVSID"
    # If a user has multiple series with the same maximum seasons, all are included
    output_part2_rdd = result_rdd.map(lambda x: f"{x[0]},{x[1]}")

    # Save to the second output folder
    # Only users who have started at least one series appear due to the initial filtering
    output_part2_rdd.saveAsTextFile(output_part2)

    sc.stop()

if __name__ == "__main__":
    main()