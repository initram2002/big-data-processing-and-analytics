package it.polito.bigdata.hadoop;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Basic MapReduce Project - Mapper
 */
class MapperBigData extends Mapper<LongWritable, Text, Text, Text> {

    protected void map(
            LongWritable key,
            Text value,
            Context context) throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");
        String city = fields[3];
        String country = fields[4];
        String princingPlan = fields[5];

        // We are interested in the cities in France
        // with a Premium or Standard plan
        // We emit the city as key and 1 as value
        if (country.equals("France") &&
                (princingPlan.equals("Premium") || princingPlan.equals("Standard"))) {
            context.write(new Text(city), new Text(princingPlan));
        }
    }
}
