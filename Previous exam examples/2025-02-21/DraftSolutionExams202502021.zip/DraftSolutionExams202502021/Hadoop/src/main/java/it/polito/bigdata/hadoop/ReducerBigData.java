package it.polito.bigdata.hadoop;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Basic MapReduce Project - Reducer
 */
class ReducerBigData extends Reducer<Text, Text, Text, NullWritable> {
    @Override
    protected void reduce(
            Text key,
            Iterable<Text> values,
            Context context) throws IOException, InterruptedException {

        int numPremium = 0;
        int numStandard = 0;

        for (Text princingPlan : values) {
            if (princingPlan.toString().equals("Premium"))
                numPremium++;
            else
                numStandard++;
        }

        if (numPremium > numStandard)
            context.write(key, NullWritable.get());
    }
}
