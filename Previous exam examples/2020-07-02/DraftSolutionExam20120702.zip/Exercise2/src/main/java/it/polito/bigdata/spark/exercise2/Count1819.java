package it.polito.bigdata.spark.exercise2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Count1819  implements Serializable {
	public int count18;
	public int count19;
	
	Count1819(int count18, int count19) {
		this.count18=count18;
		this.count19=count19;
	}

}
