package it.polito.bigdata.hadoop;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Reducer for the single-job solution.
 * For each (City, Year) group, it iterates through all energy classes and
 * maintains a frequency map to find the most common one.
 * It handles ties by selecting the class that comes first alphabetically.
 * Emits ((City,Year),TopEnergyClass)).
 */
class ReducerBigData extends Reducer<Text, Text, Text, Text> {

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {

        // Use a HashMap to store the frequency of each energy class.
        // This is memory-efficient as there are few distinct classes.
        Map<String, Integer> frequencyMap = new HashMap<>();

        for (Text value : values) {
            String energyClass = value.toString();
            frequencyMap.put(energyClass, frequencyMap.getOrDefault(energyClass, 0) + 1);
        }

        int maxCount = -1;
        String topEnergyClass = "";

        // Iterate through the frequency map to find the most frequent class.
        for (Map.Entry<String, Integer> entry : frequencyMap.entrySet()) {
            String currentClass = entry.getKey();
            int currentCount = entry.getValue();

            if (currentCount > maxCount) {
                // Found a new maximum count.
                maxCount = currentCount;
                topEnergyClass = currentClass;
            } else if (currentCount == maxCount) {
                // A tie occurred: choose the one that is alphabetically first.
                if (currentClass.compareTo(topEnergyClass) < 0) {
                    topEnergyClass = currentClass;
                }
            }
        }

        
        // Emit the final result for the group.
        context.write(new Text(key.toString()), new Text(topEnergyClass));
    }
}
