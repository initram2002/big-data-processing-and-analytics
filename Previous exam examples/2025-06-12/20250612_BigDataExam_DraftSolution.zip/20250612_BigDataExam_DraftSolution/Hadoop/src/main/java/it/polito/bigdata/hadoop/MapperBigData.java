package it.polito.bigdata.hadoop;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Mapper for the single-job solution.
 * Reads lines from Buildings.csv.
 * Emits ((City,Year), EnergyEfficiencyClass).
 */
class MapperBigData extends Mapper<LongWritable, Text, Text, Text> {

    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {

        String[] fields = value.toString().split(",");

        // Format: BuildingID,City,Country,SquareMeters,Type,Year,EnergyEfficiencyClass
        if (fields.length == 7) {
            String city = fields[1];
            String year = fields[5];
            String energyClass = fields[6];

            context.write(new Text(city + "," + year), new Text(energyClass));
        }
    }
}
