package it.polito.bigdata.hadoop.exercise13;

public class DateValue {
	
	String date;
	float value;
}
